# Evidencia de la comparación

Las 48 respuestas están en runs. Cada archivo contiene la salida de Astra, la decisión de Python, las huellas de las páginas, el prompt identificado por su huella y el uso de tokens. Las tres claves enlazan las páginas originales. Se facilitan enlaces a las publicaciones sin volver a distribuir las facturas.

Para recalcular las cifras con estas respuestas, clona https://github.com/pedroldrh/lector-facturas en la revisión indicada en sellado-test.json e instala sus dependencias. Descomprime este archivo y define LECTOR_REPO con la ruta absoluta de ese clon. Ejecuta desde la raíz:

```sh
python ensayo/score.py dev
python ensayo/score.py test
```

El protocolo, los dos prompts y el programa de ejecución están en ensayo. El coste en dólares no se ha medido. Los tokens son los declarados por el CLI. Las referencias describen esta muestra seleccionada a mano.
