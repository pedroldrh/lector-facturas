import argparse
import concurrent.futures
import hashlib
import json
import os
import random
import shutil
import subprocess
import sys
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path(os.environ.get("LECTOR_REPO", WORK.parents[1]/"outputs/lector-facturas")).resolve()
sys.path.insert(0, str(REPO))
import lector

MODEL = "gpt-6.2-astra"
F = ("emisor","nif","base","iva","retencion")
LOCK = threading.Lock()
def now():
    return datetime.now(timezone.utc).isoformat()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):
    return json.loads(path.read_text())
def save(path, obj):
    path.parent.mkdir(exist_ok=True, parents=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+"\n")
    tmp.replace(path)
def signed(path, obj):
    if path.exists():
        before=load(path)
        if before["data"] != obj:
            raise RuntimeError(f"Ha cambiado {path.name}")
    else:
        save(path, {"fecha_utc":now(), "data":obj})
def refs(part):
    path=WORK/part/"clave.json"
    rows=load(path)
    assert len({r["id"] for r in rows})==len(rows)
    return [(r, (path.parent/r["input"]).resolve()) for r in rows]
def images(key, pdf):
    folder=WORK/"imagenes"/key
    folder.mkdir(exist_ok=True,parents=True)
    pages=sorted(folder.glob("pagina-*.png"),key=lambda p:int(p.stem.split("-")[-1]))
    if not pages:
        subprocess.run(["pdftoppm","-r","150","-png",str(pdf),str(folder/"pagina")],capture_output=True,check=True,timeout=150)
        pages=sorted(folder.glob("pagina-*.png"),key=lambda p:int(p.stem.split("-")[-1]))
    assert pages
    return pages
def schema():
    p={k:{"type":[v,"null"]} for k,v in {**lector.CAMPOS,**lector.CAMPOS_QR}.items()}
    p.update(confianza_por_campo=lector.esquema_confianza(),total_simple={"type":"boolean"},incidencias={"type":"array","items":{"type":"string"}})
    return {"type":"object","properties":p,"additionalProperties":False,"required":list(p)}
def query(pages,prompt):
    # The child sees neutral filenames in a new directory and no references, transcript or preceding calls.
    with tempfile.TemporaryDirectory() as temp:
        base=Path(temp)
        cwd=base/"sesion"; cwd.mkdir()
        fmt=base/"esquema.json"; save(fmt,schema())
        reply=base/"respuesta.json"
        cmd=["codex","-a","never","exec","--ephemeral","--ignore-user-config","--skip-git-repo-check",
             "-s","read-only","-C",str(cwd),"--disable","shell_tool","--disable","apps","--disable","browser_use",
             "-c",'web_search="disabled"',"-c",'model_reasoning_effort="low"', "--model",MODEL,
             "--json","--output-schema",str(fmt),"-o",str(reply)]
        for i,path in enumerate(pages):
            image=base/f"pagina-{i+1}.png"; shutil.copyfile(path,image); cmd.extend(["-i",str(image)])
        res=subprocess.run(cmd+["--",prompt],capture_output=True,text=True,stdin=subprocess.DEVNULL,cwd=cwd,timeout=240)
        if res.returncode or not reply.exists():
            errors=[s[:250] for s in res.stdout.splitlines() if '"error"' in s][-2:]
            raise RuntimeError(f"Codex código {res.returncode}. {res.stderr[-350:]} {errors}")
        events=[]
        for s in res.stdout.splitlines():
            try: events.append(json.loads(s))
            except ValueError: pass
        usage=next((e.get("usage") for e in events if e.get("type")=="turn.completed"),None)
        assert not any(e.get("item",{}).get("type") in {"command_execution","mcp_tool_call","web_search"} for e in events)
        return load(reply),usage
def execute(item):
    key,arm,pages,qr=item
    path=WORK/"runs"/f"{key}-{arm}.json"
    if path.exists(): return
    prompt=(HERE/f"{arm}.txt").read_text()
    attempts=[]
    for attempt in range(2):
        try:
            raw,usage=query(pages,prompt)
            break
        except (OSError,RuntimeError,subprocess.TimeoutExpired,json.JSONDecodeError) as exc:
            attempts.append(str(exc)[:500])
            if attempt:
                save(WORK/"fallos"/f"{key}-{arm}.json",attempts)
                raise
    final=lector.revisar(raw,qr)
    save(path,{"id":key,"brazo":arm,"fecha_utc":now(),"referencia_modelo":MODEL,"esfuerzo":"low",
               "prompt_sha256":sha(HERE/f"{arm}.txt"),"paginas_sha256":[sha(p) for p in pages],
               "intentos_tecnicos_fallidos":attempts,"uso":usage,"modelo":raw,"lector":final})
    with LOCK: print(key,arm,"guardado",flush=True)
def main():
    cli=argparse.ArgumentParser(); cli.add_argument("set",choices=["dev","test"])
    cli.add_argument("--jobs",type=int,default=6)
    opts=cli.parse_args()
    parts=["dev"] if opts.set=="dev" else ["h1","h2"]
    arms=["A"] if opts.set=="dev" else ["A","B"]
    recs=[(r,p) for part in parts for r,p in refs(part)]
    assert len(recs)==(12 if opts.set=="dev" else 18)
    assert len({sha(p) for r,p in recs})==len(recs)
    setup={"repo":subprocess.check_output(["git","-C",str(REPO),"rev-parse","HEAD"],text=True).strip(),
           "archivos":{r["id"]:sha(p) for r,p in recs},"referencias":{p:sha(WORK/p/"clave.json") for p in parts},
           "prompts":{a:sha(HERE/f"{a}.txt") for a in arms},"protocolo":sha(HERE/"protocolo.md")}
    if opts.set=="test":
        assert (WORK/"cerrado-B.json").exists() and load(WORK/"cerrado-B.json")["B"]==setup["prompts"]["B"]
    signed(WORK/f"sellado-{opts.set}.json",setup)
    def prepare(rp):
        r,p=rp; pg=images(r["id"],p)
        return r["id"],pg,lector.leer_qr(pg)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex: docs=list(ex.map(prepare,recs))
    tasks=[(k,a,pg,q) for k,pg,q in docs for a in arms]
    random.Random(27112026).shuffle(tasks)
    with concurrent.futures.ThreadPoolExecutor(max_workers=opts.jobs) as ex:
        pending=[ex.submit(execute,task) for task in tasks]
        exceptions=[]
        for fut in concurrent.futures.as_completed(pending):
            try: fut.result()
            except Exception as e: exceptions.append(repr(e)); print(repr(e),flush=True)
        if exceptions: sys.exit(1)
if __name__=="__main__": main()
