import collections
import csv
import json
import re
import sys
import unicodedata
from decimal import Decimal
from run import F, HERE, WORK, load, refs, save

def comparable(field, value):
    if value is None: return None
    if field == "emisor":
        s=unicodedata.normalize("NFD",str(value).casefold()).replace("\u0301","")
        return "".join(c for c in unicodedata.normalize("NFC",s) if c.isalnum())
    if field == "nif":
        s=re.sub(r"[\s.\-/]","",str(value).upper())
        return s[2:] if len(s)==11 and s.startswith("ES") else s
    return Decimal(str(value).replace(",","."))

def check(key,arm):
    run=load(WORK/"runs"/f"{key['id']}-{arm}.json")
    final=run["lector"]
    expected=set(key["campos_revision"])
    assert expected.issubset(F)
    needs_doc=bool(expected) or bool(key.get("revision_documento",False))
    observed=final["estado"]=="revisar"
    data={"id":key["id"],"brazo":arm,"requiere_revision":needs_doc,"pidio_revision":observed,
          "revision_sobrante":observed and not needs_doc,"revision_justificada":observed and needs_doc,
          "revision_omitida":not observed and needs_doc,"motivos":final["motivos"]}
    detail=[]
    for field in F:
        info=final["revision_campos"][field]
        accepted=info["decision"]!="revisar"
        ref=key[field]; value=final[field]
        choices=[ref]+key.get("equivalencias",{}).get(field,[])
        if field=="retencion" and ref is None and field not in expected:
            choices.append(0)
        correct=comparable(field,value) in {comparable(field,c) for c in choices}
        detail.append({"campo":field,"referencia":ref,"lectura":run["modelo"][field],"utilizable":value,
                       "decision":info["decision"],"legibilidad":info["legibilidad"],
                       "revision_esperada":field in expected,"error_aceptado":accepted and not correct,
                       "acierto_sin_respaldo":accepted and correct and field in expected,
                       "revision_sobrante":not accepted and field not in expected})
    data["campos"]=detail
    return data

def summarize(docs):
    allfields=[f for d in docs for f in d["campos"]]
    wrong=lambda d:any(f["error_aceptado"] for f in d["campos"])
    return {"facturas":len(docs),"campos":len(allfields),
            "campos_erroneos_aceptados":sum(f["error_aceptado"] for f in allfields),
            "facturas_con_error_aceptado":sum(wrong(d) for d in docs),
            "facturas_aceptadas_enteras_con_error":sum(wrong(d) and not d["pidio_revision"] for d in docs),
            "campos_aceptados_sin_respaldo_pero_acertados":sum(f["acierto_sin_respaldo"] for f in allfields),
            "facturas_resolubles":sum(not d["requiere_revision"] for d in docs),
            "revisiones_sobrantes_factura":sum(d["revision_sobrante"] for d in docs),
            "revisiones_sobrantes_campo":sum(f["revision_sobrante"] for f in allfields),
            "revisiones_justificadas_factura":sum(d["revision_justificada"] for d in docs),
            "revisiones_omitidas_factura":sum(d["revision_omitida"] for d in docs),
            "revisiones_totales_factura":sum(d["pidio_revision"] for d in docs)}

if __name__=="__main__":
    group=sys.argv[1]
    arms=["A"] if group=="dev" else ["A","B"]
    keys=[r for part in (["dev"] if group=="dev" else ["h1","h2"]) for r,p in refs(part)]
    allrows=[]
    for arm in arms:
        docs=[check(k,arm) for k in keys]
        allrows.extend(docs)
        print(arm,summarize(docs))
        for d in docs:
            anomalies=[(f['campo'],f['lectura'],f['utilizable'],f['referencia'],f['decision'])
                       for f in d["campos"] if f['error_aceptado'] or f['revision_sobrante'] or f['acierto_sin_respaldo']]
            if anomalies or d['pidio_revision']:
                print(d['id'], anomalies, d['motivos'])
    save(WORK/f"puntuacion-{group}.json",allrows)
